require('dotenv').config();

const {
    Client,
    GatewayIntentBits,
    SlashCommandBuilder,
    REST,
    Routes,
    PermissionFlagsBits,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle
} = require('discord.js');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers
    ]
});

let campaign = {
    running: false,
    status: 'Idle',
    roleName: null,
    reward: null,
    total: 0,
    processed: 0,
    sent: 0,
    failed: 0
};

const commands = [
    new SlashCommandBuilder()
        .setName('dmrole')
        .setDescription('Send a reward DM to members with a selected role')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('Role whose members will receive the DM')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reward')
                .setDescription('Reward name')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('message')
                .setDescription('Message shown inside the embed')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('claimlink')
                .setDescription('Claim URL')
                .setRequired(true)
        )
        .toJSON(),

    new SlashCommandBuilder()
        .setName('progress')
        .setDescription('Show DM campaign progress')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .toJSON()
];

client.once('ready', async () => {
    console.log(`Logged in as ${client.user.tag}`);

    try {
        const rest = new REST({ version: '10' })
            .setToken(process.env.BOT_TOKEN);

        await rest.put(
            Routes.applicationCommands(client.user.id),
            { body: commands }
        );

        console.log('Slash commands registered globally.');
        console.log('Bot is ready.');
    } catch (error) {
        console.error('Command registration error:', error);
    }
});

client.on('interactionCreate', async interaction => {
    if (
        interaction.isChatInputCommand() &&
        interaction.commandName === 'progress'
    ) {
        if (!campaign.running && campaign.total === 0) {
            return interaction.reply({
                content: '📭 No DM campaign has been started yet.',
                ephemeral: true
            });
        }

        const remaining = Math.max(
            0,
            campaign.total - campaign.processed
        );

        const status =
            campaign.running
                ? '🟢 Running'
                : campaign.status === 'Completed'
                    ? '✅ Completed'
                    : '⏹️ Stopped';

        return interaction.reply({
            content:
                `📨 **DM Campaign Progress**\n\n` +
                `Status: ${status}\n` +
                `Role: **${campaign.roleName}**\n` +
                `Reward: **${campaign.reward}**\n\n` +
                `Progress: **${campaign.processed}/${campaign.total}**\n` +
                `✅ Sent: **${campaign.sent}**\n` +
                `❌ Failed: **${campaign.failed}**\n` +
                `📬 Remaining: **${remaining}**`,
            ephemeral: true
        });
    }

    if (
        !interaction.isChatInputCommand() ||
        interaction.commandName !== 'dmrole'
    ) {
        return;
    }

    if (campaign.running) {
        return interaction.reply({
            content:
                '⚠️ A DM campaign is already running.\n' +
                'Use `/progress` to check it.',
            ephemeral: true
        });
    }

    const role = interaction.options.getRole('role');
    const reward = interaction.options.getString('reward');
    const message = interaction.options.getString('message');
    const claimLink = interaction.options.getString('claimlink');

    try {
        const url = new URL(claimLink);

        if (!['http:', 'https:'].includes(url.protocol)) {
            throw new Error('Invalid protocol');
        }
    } catch {
        return interaction.reply({
            content:
                '❌ Invalid claim link.\n' +
                'Use a URL beginning with `https://`.',
            ephemeral: true
        });
    }

    await interaction.deferReply({ ephemeral: true });

    try {
        const members = await interaction.guild.members.fetch();

        const targets = members.filter(member =>
            !member.user.bot &&
            member.roles.cache.has(role.id)
        );

        if (targets.size === 0) {
            return interaction.editReply(
                `❌ No non-bot members were found with ${role}.`
            );
        }

        campaign = {
            running: true,
            status: 'Running',
            roleName: role.name,
            reward,
            total: targets.size,
            processed: 0,
            sent: 0,
            failed: 0
        };

        const embed = new EmbedBuilder()
            .setColor('#00FFFF')
            .setTitle(`🎉 You WON ${reward}!`)
            .setDescription(
                `## 🎁 Claim Your Prize\n\n` +
                `${message}\n\n` +
                `-# ${reward} GIVEAWAY 🎉`
            );

        const button = new ButtonBuilder()
            .setLabel('Click to Claim')
            .setStyle(ButtonStyle.Link)
            .setURL(claimLink);

        const row = new ActionRowBuilder()
            .addComponents(button);

        await interaction.editReply(
            `📨 **DM campaign started!**\n\n` +
            `Role: ${role}\n` +
            `Recipients: **${targets.size}**\n\n` +
            `Use \`/progress\` to check progress.`
        );

        console.log(
            `DM campaign started | Role: ${role.name} | ` +
            `Reward: ${reward} | Total: ${targets.size}`
        );

        for (const member of targets.values()) {
            try {
                await member.send({
                    embeds: [embed],
                    components: [row]
                });

                campaign.sent++;
                console.log(`DM sent to ${member.user.tag}`);

            } catch (error) {
                campaign.failed++;
                console.log(
                    `Failed to DM ${member.user.tag}: ${error.message}`
                );

                if (error.code === 429 || error.status === 429) {
                    console.log(
                        'Discord rate limit encountered. Stopping campaign.'
                    );
                    break;
                }
            }

            campaign.processed++;
        }

        campaign.running = false;
        campaign.status = 'Completed';

        console.log(
            `DM campaign completed | Total: ${campaign.total} | ` +
            `Sent: ${campaign.sent} | Failed: ${campaign.failed}`
        );

        await interaction.editReply(
            `🎉 **DM campaign completed!**\n\n` +
            `🎁 Reward: **${reward}**\n` +
            `👥 Recipients: **${campaign.total}**\n` +
            `✅ Sent: **${campaign.sent}**\n` +
            `❌ Failed: **${campaign.failed}**\n\n` +
            `Use \`/progress\` to view the final results.`
        );

    } catch (error) {
        console.error('DM campaign error:', error);

        campaign.running = false;
        campaign.status = 'Stopped';

        try {
            await interaction.editReply(
                `❌ **Campaign stopped.**\n\n` +
                `Processed: **${campaign.processed}/${campaign.total}**\n` +
                `✅ Sent: **${campaign.sent}**\n` +
                `❌ Failed: **${campaign.failed}**\n\n` +
                `Error: ${error.message}`
            );
        } catch {}
    }
});

client.login(process.env.BOT_TOKEN);
