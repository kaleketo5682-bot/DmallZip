# DM Bot

## Files
- index.js
- package.json
- .env.example
- .gitignore

## Setup
1. Rename `.env.example` to `.env`.
2. Put your new Discord bot token in `.env`.
3. Run `npm install`.
4. Run `npm start`.

## Discord Developer Portal
This bot uses `GuildMembers`, so enable:
Bot -> Privileged Gateway Intents -> Server Members Intent.

## Commands
- `/dmrole` - select a role, reward, message and claim URL.
- `/progress` - view the current campaign progress.

The bot sends a real Discord embed with a link button. It does not attempt to bypass Discord rate limits.
